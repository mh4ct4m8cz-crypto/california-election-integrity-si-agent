# California Election Integrity SI Agent

Starter Next.js app for building and testing a neutral, evidence-focused California Election Integrity SI Agent.

## Included
- SI Agent intake
- Build My SI Agent button
- Master SI Agent prompt
- Knowledge-base/source structure
- Primary-source registry
- Test SI Agent page
- Server-side OpenAI API route
- Vercel-ready structure

## Local setup
1. `npm install`
2. Copy `.env.example` to `.env.local`
3. Add `OPENAI_API_KEY`
4. Set `OPENAI_MODEL` to the current model ID you choose
5. `npm run dev`
6. Open `http://localhost:3000`

## Vercel
Import the GitHub repository into Vercel. Add `OPENAI_API_KEY` and `OPENAI_MODEL` as environment variables. Never expose the API key client-side.

## Next production upgrade
Add live retrieval/search over current California statutes, regulations, Secretary of State material, county sources, court decisions, and official investigations. The initial registry is deliberately only a starting source configuration.
