import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata={title:"California Election Integrity SI Agent",description:"Evidence-focused California election information SI Agent builder."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
